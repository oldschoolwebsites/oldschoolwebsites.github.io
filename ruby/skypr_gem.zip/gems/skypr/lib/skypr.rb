$:.unshift(File.dirname(__FILE__)) unless
  $:.include?(File.dirname(__FILE__)) || $:.include?(File.expand_path(File.dirname(__FILE__)))

PLATFORM = "universal-darwin9.0"  
require 'appscript'
require 'colored'  

require 'skypr/helpers.rb' 
require 'skypr/message.rb' 
require 'skypr/msg_queue.rb' 
require 'skypr/chatter.rb'  
require 'skypr/responder.rb'

module Skypr
  VERSION = '0.0.2'
end
