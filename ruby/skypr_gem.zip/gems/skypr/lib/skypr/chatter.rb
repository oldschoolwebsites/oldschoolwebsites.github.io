module Skypr
	# Chatter is responsible of:
	# - getting last message sent to Skype server,
	# - and sending message back to client.
	#
	# Depends on:
	# - Apple's Appscript, 
	# - Helpers module with :command method that wraps around Skype API 
	#
	# Chatter attributes:
	# - @client_name, describess skype client
	# - @chat_id, describes skype's chat connection id
	# 
	# Chatter methods:
	# - msg
	# - msg=
	# 
 class Chatter
    include Appscript
    include Helpers      
    attr_reader :chat_id, :client_name, :own_name
    
    def initialize(client_name) #creates chat with client
      command "PROTOCOL 8"
      @client_name = client_name 
      @chat_id = create_chat_with(@client_name).match(/CHAT ([#\w\.\/$;]*)/)[1]
        
      @own_name = (command "get chat #{@chat_id} members").split[-1]
      greeting
      
    end
    
    def msg #returns last message recived from client
      messages = []
      recent_chatmessages_ids.each do |msg_id|
        msg_author = command("GET CHATMESSAGE #{msg_id} FROM_HANDLE")
        msg_body =command("GET CHATMESSAGE #{msg_id} BODY")
        msg_timestamp =command("GET CHATMESSAGE #{msg_id} TIMESTAMP")

        (msg_author = msg_author.split[-1].to_str) if msg_author =~ /\w+ \d+ FROM_HANDLE(.*)/         
        (msg_body = $1.strip) if msg_body =~ /\w+ \d+ BODY(.*)/

        (msg_timestamp = msg_timestamp.split[-1].to_i) if msg_timestamp =~ /\w+ \d+ TIMESTAMP(.*)/       

        messages << Message.new(msg_author, msg_body, msg_timestamp) # returns new Message object
      end
      messages.compact.sort_by(&:timestamp)[-1] 
    end
    
    def msg=(new_msg)    #sends chat message to client
      return "OK" if command("CHATMESSAGE #{@chat_id} #{new_msg}")
      "failed"
      
    end
  
    private
    def create_chat_with(client_name)
      command "CHAT CREATE #{client_name}"
    end
    def recent_chatmessages_ids
      #response = command "SEARCH RECENTCHATS"
      # current_czat_id = response[6..-1]
      # messages = command "GET CHAT #{current_czat_id} recentchatmessages"
      messages = command "GET CHAT #{@chat_id} recentchatmessages"
      messages.split.map {|i| i.to_i }.select {|i| i > 0} #that is dirty way of getting array of msg id's need to be changed
    end
    
    def greeting
      msg="#{@own_name} - Ready to serve, mastah[#{@client_name}]." 
    end  
  end
end   
