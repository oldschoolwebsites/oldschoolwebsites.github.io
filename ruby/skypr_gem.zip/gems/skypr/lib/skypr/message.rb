module Skypr
  class Message
     attr_accessor :author, :body, :timestamp

     def initialize(author, body,timestamp)
      @author, @body, @timestamp = author, body, timestamp
     end

     def ==(other)
       self.body == other.body && self.timestamp == other.timestamp && self.author == other.author
     end

     def to_s
       self.body
     end
  end 
end
