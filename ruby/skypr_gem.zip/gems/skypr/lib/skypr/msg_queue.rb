module Skypr
 MsgQueue = Class.new(Array)

  class MsgQueue
    def add(message)
      self << message
      self.uniq!
    end
      
  end 
end
