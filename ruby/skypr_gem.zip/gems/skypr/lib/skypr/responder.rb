module Skypr
	# Responder is responsible of:
	# - maintain connection with skype client,
	# - keeping loaded appz,
	# - responding to new request
	#
	#
	# Depends on:
	# - Skypr::Chatter,
	#
	# Responder attributes:
	# - @chatter,reference to Chatter object
	# - @appz, hash with shortcut => app reference
	# 
	# Chatter methods:
	# - load_appz
	# - router
	# 

  class Responder
    attr_accessor :appz
    attr_reader :chatter

    def initialize(client_name, *appz, &block)
	    @appz = {}    
	    @chatter = Skypr::Chatter.new(client_name)
	    @prev_recived_msg_body = nil
	    load_appz(appz) unless appz.nil?
	    router &block
    end  
  
    def load_appz(appz)
      appz.each do |app|
        @appz[app.shortcut] = app if app.respond_to? :shortcut
        app.setup if app.respond_to? :setup
      end              
    end

    def router &block
      resp = Thread.new do
        loop do
          recived_msg = @chatter.msg unless @chatter.msg.nil?  
          unless @prev_recived_msg_body == recived_msg.body
            command = recived_msg.body 
            @prev_recived_msg_body = recived_msg.body 
	    yield command 
       	  end
        end
      end 
    end
  end

end   
