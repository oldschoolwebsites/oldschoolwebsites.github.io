module Skypr
  module Helpers                
    def command(cmd)
      app('Skype').send_ :command => cmd, :script_name => ''
    end    
  end
end
